# Handoff: Sinclairs (BVI) — WordPress theme/plugin rebuild

## Overview
Redesign of sinclairsbvi.com — a BVI law firm site. Home, About, Our Services (hub + 8 practice-area pages), Our Articles, Contact. Built and approved as an HTML/React design prototype; this package is for rebuilding it as a WordPress theme (or a companion plugin for CPTs) in Codex.

## About the design files
`reference/Sinclairs-BVI.dc.html` is a **design reference**, not code to lift as-is. It's a single-file React-ish component (custom "DC" runtime — ignore `<x-dc>`/`support.js`/`{{ }}` templating mechanics, they don't exist in WordPress). Treat it as the source of truth for layout, copy, states and motion; rebuild it with standard WordPress patterns.

## Fidelity
High-fidelity for layout, spacing, copy and interaction. Colors/type currently run on a placeholder design system (Broadsheet — see tokens below); accent color and logo are real (client-supplied), photography is still placeholder drop-slots.

## Recommended WordPress approach
Build a **custom theme** (not a page builder). Suggested structure:
- Classic PHP theme with `functions.php`, `header.php`, `footer.php`, page templates per section (`front-page.php`, `page-about.php`, `page-services.php`, `page-{service-slug}.php`, `page-articles.php`, `page-contact.php`), OR a block theme (`theme.json` + block templates) if the client wants the WP block editor for content.
- Register a **Custom Post Type `service`** (8 items) with fields: title, order/menu index (01–08), one-line "nutshell" summary, full body copy, FAQ repeater (question/answer pairs), featured image. Use ACF or native block fields — Codex's call.
- Register a **Custom Post Type `article`** for Our Articles (title, standfirst, category taxonomy, body, featured image).
- The mega-menu, home "Choose a practice area" hover list, and the Services hub all read from the same 8 `service` posts — build one query, reuse in three templates, so editing a service in wp-admin updates the menu, hub, and page consistently.
- Testimonials: either a `testimonial` CPT (3+ items, rotates in JS) or ACF repeater on the front page.

## Screens / views
1. **Home** — full-bleed hero photo (`--hero`) with gradient + headline/subhead/two CTAs; intro two-column statement; "Choose a practice area" — left column list of 8 service names (hover/focus swaps a sticky photo + one-paragraph summary on the right, desktop only — collapses to a plain stacked list on mobile); "Our Articles" teaser (heading, 2 lines, link, photo); rotating testimonial (3 quotes, auto-advances 7s, tab dots); closing CTA band.
2. **About** — thin header banner photo, h1, two-column body copy + sticky portrait photo.
3. **Our Services (hub)** — banner, h1 + subhead ("in a nutshell"), then repeating pattern per group (Corporate & Commercial Law / Investment Funds group / Private Client Law): sticky group heading on the left, list of service rows on the right — each row is a link with bold service name + one-line nutshell description ("Information & FAQs" merge — see below).
4. **8 Practice-area pages** (Corporate & Commercial, Investment Funds & Approved Managers, Banking & Corporate Finance, AML/CFT & Regulatory Compliance, Virtual Assets & FinTech, Economic Substance, Property & Private Client, Liquidations/Trade Marks/Notarial) — banner, h1, one-line dek, full body copy (verbatim from client's 28 July docs — see `reference/source-copy/`), "Information & FAQs" accordion (native `<details>`/`<summary>` in the prototype — build as an accessible accordion), "next practice area" link footer.
5. **Our Articles** — banner, h1 "Notes on BVI law, written plainly", 3 sample article rows (headline + standfirst) — wire to the `article` CPT loop.
6. **Contact** — banner, h1, office/phone/email block (address per client — confirm before launch), enquiry form (name/email/area of interest/message) — wire to Contact Form 7, WPForms or a custom handler; disclaimer line under the form.

## Global chrome
- **Header**: sticky, logo image left (`reference/assets/sinclairs-logo.png`, PNG w/ transparency), nav right — Home / About / "Our Services" (hover or click opens a mega-menu of all 8 services, each with its one-line nutshell blurb) / Our Articles / Contact button. Collapses to a full-screen mobile drawer under 900px, hamburger icon.
- **Footer**: 4-column — brand blurb, Services links, More links (Economic Substance, Property, Liquidations, About, Articles), Contact block. Bottom bar: copyright + legal-advice disclaimer.
- **FAQ heading toggle**: client can flip each service's FAQ block between "Information & FAQs" (merged heading, current default) and a plain "Frequently Asked Questions" heading — make this a theme option or per-CPT field, not hardcoded.

## Interactions & behavior
- Header mega-menu: opens on hover (desktop, `mouseenter`/`mouseleave` with no delay in the prototype — add a small close-delay in production to avoid flicker) and on click.
- "Choose a practice area" list (home): `mouseenter`/`focus` on a row crossfades (`opacity` transition, ~0.55s ease) to that service's photo + paragraph in a sticky right-hand panel. Falls back to a plain list (no hover panel) on mobile — check `isMobile`/`isDesktop` breakpoint at 900px in the prototype.
- Testimonial rotator: crossfades every 7s (`setInterval`), pauses conceptually when off the home page; three dot buttons let a user jump directly; active dot goes to full opacity, others to ~0.22.
- FAQ accordions: native disclosure, one `<details>` per Q&A, custom chevron/plus icon that should rotate or swap glyph on open (prototype uses a static "+"; add a real open/close icon in production).
- Scroll-reveal: on-scroll fade/rise for most section blocks (`animation-timeline: view()` in the prototype — a CSS feature not universally supported; reimplement with an IntersectionObserver + CSS class toggle, or a small library like AOS, for cross-browser reliability in WordPress).
- All internal navigation in the prototype is client-side (fake links); in WordPress these become real page URLs — see the sitemap below for slugs.

## Design tokens (current placeholder system — swap for final brand values)
- Background: `#f3f2f2` · Surface (alt sections): `#eae9e9` · Text: `#201e1d`
- Accent (interactive/links): `#0e7c93` (client tweak from Broadsheet's default `#0088b0`) — full ramp in `reference/broadsheet-tokens.css`
- Divider: `color-mix(#201e1d 16%, transparent)` → resolve to a literal hex for WP (~`#d9d8d8`)
- Type: Source Serif 4 for both headings and body (headings weight 600, italic for pull-quotes/emphasis) — see Google Fonts import in `broadsheet-tokens.css`
- Spacing scale: 5/10/15/20/30px steps (`--space-1..6`), used throughout — recreate as a Sass/CSS custom-property scale
- Photo treatment: `.cmyk`/`.print` class does a 4-color misregistration filter effect on photos (decorative, from the placeholder design system) — **confirm with client whether they want this or plain photography**; likely drop it for a law firm site and use clean, color-corrected photos instead.

⚠️ These are placeholder-system tokens, not the client's real brand guide. Confirm final hex codes, font license, and whether the CMYK photo-treatment stays before building.

## Assets
- `reference/assets/sinclairs-logo.png` — client logo (transparent PNG, 333×185)
- `reference/assets/bvi-harbour.jpg` — one client-supplied harbour photo, currently reused as a placeholder in several slots (hero, practice-area teaser, articles teaser) — **replace each with a distinct photo from the client's full set** before launch; every image position in the prototype is a distinct drop-slot (`<image-slot id="...">`), listed by id in the DC file, so treat each id as one required photo.
- All body copy for About, the 8 service pages and their FAQs is verbatim from the client's Word docs, extracted to plain text in `reference/source-copy/*.txt` for easy diffing against the live page copy.

## Content still outstanding (flag to client before launch)
- One service group ("Economic Substance, Banking & Finance, Trusts & Estates, Voluntary Liquidation, Trade Marks, Notarial Services") is missing its dedicated source Word doc — current copy is assembled from the Nutshell doc + the Corporate & Commercial doc as a stand-in, and has no FAQs yet.
- Contact details (address, phone numbers) need client confirmation — current values were pulled from public BVI FSC records, not from the client.
- Real photography for most slots (see Assets above).

## Sitemap / URL slugs (suggested)
```
/                          Home
/about/                    About Sinclairs (BVI)
/services/                 Our Services (hub, "in a nutshell")
/services/corporate-commercial/
/services/investment-funds/
/services/banking-finance/
/services/aml-cft-compliance/
/services/virtual-assets-fintech/
/services/economic-substance/
/services/property-private-client/
/services/liquidations-trademarks-notarial/
/articles/                 Our Articles (index)
/articles/{post-slug}/     Individual article
/contact/
```

## Files in this package
- `reference/Sinclairs-BVI.dc.html` — full design reference, all pages/states in one file
- `reference/assets/` — logo + sample photo
- `reference/source-copy/*.txt` — client's Word-doc copy, extracted, one file per document
- `reference/broadsheet-tokens.css` — the placeholder design-system's full token sheet (colors, type, spacing, components) for reference only
